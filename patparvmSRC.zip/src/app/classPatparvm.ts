
export class PatparvmPersonal
{
    patparvmName!: string;
    patparvmNumber!: number;
    patparvmLogin!: string;
    patparvmEmail!: string;
    patparvmCampus!: string;
    patparvmImage!: string;

}

export class PatparvmCountry
{
    patparvmCountryName!: string;
    patparvmCountryId!: number;
    patparvmCountryCapital!: string;
    patparvmAvgSalary!: number;
    patparvmImage!: string;

}